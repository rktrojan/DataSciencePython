from flask import Flask,request,render_template,jsonify
  
app = Flask(__name__) #creating the Flask class object   
 
    
@app.route('/') #decorator drfines the   
def home():  
    return render_template("index.html")

#CSS
#IMAGE
#GET  POST PUT

@app.route('/LR') #decorator drfines the   
def LR():  
    return "LINEAR REGRESSION";  
      

    
if __name__ =='__main__':  
    #app.run(debug = True)  
    app.run(debug=True, use_reloader=False)
    
    

    
    
